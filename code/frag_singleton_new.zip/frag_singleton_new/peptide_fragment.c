#include <stdio.h>
#include "peptide_fragment.h"

void analyze (char * peptide)
{
  printf ("peptide: %s\n", peptide);
}
