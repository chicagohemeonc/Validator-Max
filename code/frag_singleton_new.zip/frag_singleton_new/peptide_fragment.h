void analyze ( char * peptide );
